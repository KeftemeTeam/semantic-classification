from engine.prompt_builder import PromptBuilder
from engine.language_model import LanguageModel
from engine.response_filter import ResponseFilter
from engine.loader.data_filter import DataFilter
from engine.loader.impl.csv_loader import CSVLoader

cl = CSVLoader()
df = DataFilter()
rf = ResponseFilter(["доверенность", "договор", "акт", "заявление", "приказ", "счет", "приложение", "соглашение", "договор оферты", "устав", "решение"])
pb = PromptBuilder("prompts")
lm = LanguageModel("TheBloke/Mistral-7B-Instruct-v0.2-GGUF", "mistral-7b-instruct-v0.2.Q8_0.gguf", gpu_cores=320, context_size=32768)

data = cl.load_dataset(open(f'data_files/dataset.csv', encoding='utf-8').read())

result = open('result.csv', encoding='utf-8', mode='a')
result.write('document_id;class_id\n')

mapping = {"доверенность": 1,
"договор": 2,
"акт": 3,
"заявление": 4,
"приказ": 5,
"счет": 6,
"приложение": 7,
"соглашение": 8,
"договор оферты": 9,
"устав": 10,
"решение": 11
}


for num, x in enumerate(data):
    prompt = pb.build_prompt('best_3', df.filter(x['text']))

    try:
        result.write(f"{x['id']};{mapping[rf.filter(lm.generate(prompt, token_limit=128))]}\n")
    except:
        pass
