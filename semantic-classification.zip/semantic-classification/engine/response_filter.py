class ResponseFilter():
    def __init__(self, labels):
        self.labels = labels
    
    def filter(self, label):
        for x in label.split():
            x = ''.join(filter(str.isalpha, x.lower()))

            if x in self.labels:
                return x
            