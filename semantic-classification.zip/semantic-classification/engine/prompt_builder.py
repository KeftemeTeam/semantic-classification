import os


class PromptBuilder(object):
    def __init__(self, path):
        prompts = {}

        for file in os.listdir(path):
            prompts[file.split(".")[0]] = open(f"{path}/{file}", encoding='utf-8').read()
        
        self.prompts = prompts

        
    def build_prompt(self, name, text):
        if name not in self.prompts:
            raise RuntimeError(f"Unknown prompt {name}")

        return self.prompts[name] + "\n" + text