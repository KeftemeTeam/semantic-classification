from llama_cpp import Llama


class LanguageModel(object):
    def __init__(self, model_repository, model_file, gpu_cores, context_size, debug_mode=False):
        self.model = Llama.from_pretrained(
            repo_id=model_repository,
            filename=model_file,
            n_gpu_layers=gpu_cores, # GPU acceleration
            n_ctx=context_size, # context window
            verbose=debug_mode,
        )

    
    def wrap_prompt(self, prompt):
        return f"<s>[INST] {prompt} [/INST]"

      
    def generate(self, prompt, token_limit=None):
        prompt = self.wrap_prompt(prompt)

        model_response = self.model(
            prompt=prompt,
            max_tokens=token_limit,
            stop=["</s>"],
            echo=False
        )

        return model_response['choices'][0]['text'].strip()

