class DataLoader(object):
    # returns [{"text": "a"}, {"text": "b"}]
    def load_dataset(self, data):
        raise RuntimeError("Not implemented")

    # returns [{"label": 1, "text": "a"}, {"label": 2, "text": "b"}]
    def load_train_dataset(self, data):
        raise RuntimeError("Not implemented")
