from engine.loader.data_loader import DataLoader
import docx2txt

class DOCXLoader(DataLoader):
    def load_dataset(self, data):
         
        extracted_text = docx2txt.process(data)
        return [{"text": extracted_text}]