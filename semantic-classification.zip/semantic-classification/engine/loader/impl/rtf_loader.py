from engine.loader.data_loader import DataLoader
from rtf_converter import rtf_to_txt

class RTFLoader(DataLoader):
    def load_dataset(self, data):

        plain_text = rtf_to_txt(data)
        return [{"text": plain_text}]