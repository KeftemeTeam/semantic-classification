import csv

from io import StringIO

from engine.loader.data_loader import DataLoader

class CSVLoader(DataLoader):
    mapping = {
        "proxy": "доверенность",
        "contract": "договор",
        "act": "акт",
        "application": "заявление",
        "order": "приказ",
        "invoice": "счет",
        "bill": "приложение",
        "arrangement": "соглашение",
        "contract offer": "договор оферты",
        "statute": "устав",
        "determination": "решение"
    }


    def load_train_dataset(self, data):
        res = []
        ios = StringIO(data)

        for row in csv.reader(ios):
            if row[0] in self.mapping.keys():
                res.append({'label': self.mapping[row[0]], 'text': row[1].replace("\t", "")})

        return res

    def load_dataset(self, data):
        res = []
        ios = StringIO(data)

        for row in csv.reader(ios, delimiter='|'):
            if row[0] != 'document_id':
                res.append({'id': row[0], 'text': row[1].replace("\t", "")})

        return res
