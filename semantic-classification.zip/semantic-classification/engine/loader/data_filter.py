class DataFilter(object):
    def filter(self, data):
        data = " ".join(data.split("\n"))
        data = " ".join(data.split())
        return data