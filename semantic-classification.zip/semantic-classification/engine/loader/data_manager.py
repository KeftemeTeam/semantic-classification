class DataManager(object):
    # singleton pattern
    def __new__(self):
        if not hasattr(self, 'instance'):
            self.instance = super(DataManager, self).__new__(self)
            return self.instance
        
    def __init__(self):
        self.loaders = {}

    def register_loader(self, name, loader):
        self.loaders[name] = loader

    def unregister_loader(self, name):
        del self.loaders[name]

    def get_loader(self, name):
        return self.loaders[name]

    def load_dataset(self, name, data):
        if name in self.loaders:
            return self.loaders[name].load_dataset(data)
        print(f"[WARN] Unable to find a data loader for the type ${name}")
        return []

    def load_train_dataset(self, name, data):
        if name in self.loaders:
            return self.loaders[name].load_train_dataset(data)
        print(f"[WARN] Unable to find a data loader for the type ${name}")
        return []
