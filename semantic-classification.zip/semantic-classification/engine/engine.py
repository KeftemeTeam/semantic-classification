from engine.prompt_builder import PromptBuilder
from engine.language_model import LanguageModel
from engine.response_filter import ResponseFilter
from engine.loader.data_filter import DataFilter

from engine.loader.data_manager import DataManager
from engine.loader.impl.csv_loader import CSVLoader
from engine.loader.impl.rtf_loader import RTFLoader
from engine.loader.impl.docx_loader import DOCXLoader


class ModelConfig(object):
    def __init__(self, model_repository, model_name, gpu_cores, context_size):
        self.model_repository = model_repository
        self.model_name = model_name
        self.gpu_cores = gpu_cores
        self.context_size = context_size


class Engine(object):
    def __init__(self, model_config, labels, prompt_name):
        self.data_filter = DataFilter()
        self.data_manager = DataManager()

        self.data_manager.register_loader('csv', CSVLoader())
        self.data_manager.register_loader('rtf', RTFLoader())
        self.data_manager.register_loader('docx', DOCXLoader())
        
        self.prompt_name = prompt_name
        self.prompt_builder = PromptBuilder("prompts")
        
        self.response_filter = ResponseFilter(labels)
        self.language_model = LanguageModel(model_config.model_repository, model_config.model_name, gpu_cores=model_config.gpu_cores, context_size=model_config.context_size)


    def process_file(self, type, file_contents):
        dataset = self.data_manager.load_dataset(type, file_contents)
        result = []

        for data in dataset:
            data['text'] = self.data_filter.filter(data['text'])
            prompt = self.prompt_builder.build_prompt(self.prompt_name, data['text'])

            result.append(self.response_filter.filter(self.language_model.generate(prompt, token_limit=128)))
        
        return result
