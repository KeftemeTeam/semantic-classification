# variables throughout the usage of website
class variables():
    global doc_type
    doc_type = ''  # школьные документы, документы в ВУЗ, документы на работу