from flask_wtf import FlaskForm
from wtforms import MultipleFileField, SubmitField


class UploadFileForm(FlaskForm):
    file = MultipleFileField("Files")
    submit = SubmitField("Upload Files")