from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField


class SimpleForm(FlaskForm):
    doc_type = SelectField(u'Document Type', 
    choices=[('школьные документы', 'Документы в школу'), ('документы в ВУЗ', 'Документы в ВУЗ'), ('документы на работу', 'Документы на работу')])  # и другие
    submit = SubmitField("Enter")