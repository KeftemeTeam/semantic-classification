
from engine.engine import Engine, ModelConfig
from flask import Flask, Blueprint, render_template
from flask import url_for, request, redirect
import os
import sys
from pathlib import Path

from variables import variables


waiting = Blueprint('waiting', __name__)

path=Path(r"D:\\hackathon\\semantic-classification\\website\\static\\files") #по другому ебучий патч не хочет работать

prompt = "best-3"
labels = ["доверенность", "договор", "акт", "заявление", "приказ", "счет", "приложение", "соглашение", "договор оферты", "устав", "решение"]
model_config = ModelConfig("TheBloke/Mistral-7B-Instruct-v0.2-GGUF", "mistral-7b-instruct-v0.2.Q8_0.gguf", gpu_cores=320, context_size=32768)

engine = Engine(model_config, labels, "best_3")

def process_files():
    files = os.listdir(path)
    texts=[]
    for i in files:
        file_contents = open("D:\\hackathon\\semantic-classification\\website\\static\\files\\"+i, encoding='utf-8').read()
        texts.append(engine.process_file(i.split(".")[-1].lower(), file_contents))
    return texts

def some_function():
    d_type = ["справка", "заявление", "заявление"] #это просто список какие документы и в каком количестве нужны(просто для теста)
    lst = []
    missed = []
    texts = process_files()
    for n_type in texts:
        if n_type in d_type:
            d_type.remove(n_type) #удаляем из списка которых еще не нашли
            lst.append(n_type) #список найденных
    missed = d_type #все типы которые не нашли
    # работа модели
    # в lst закидываете, какие типы документов нашли
    # в missed закидываете, что не хватает, основываясь на целях пользователя (школьник, студент, рабочий, тд)
    doc_type = variables.doc_type  # школьные документы, документы в ВУЗ, документы на работу

    return result(lst, missed)

@waiting.route('/waiting')
def sleeping():
    return some_function()


@waiting.route('/result')
def result(lst, missed):
    #lst = ["справка", "заявление"]
    #missed = []
    s = ', '.join(lst)
    if len(missed) != 0:
        res = "Вам не хватает:" + ', '.join(missed)
    else:
        res = f"Ваши {variables.doc_type} будут рассмотрены"
    return render_template('result.html', docs=s, res=res)