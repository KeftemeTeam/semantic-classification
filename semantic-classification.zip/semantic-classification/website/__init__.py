from flask import Flask


def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = '123456'
    app.config['UPLOAD_FOLDER'] = '/files'

    from .views import views
    from .waiting import waiting

    app.register_blueprint(views, url_prefix='/')
    app.register_blueprint(waiting, url_prefix='/')
    

    return app