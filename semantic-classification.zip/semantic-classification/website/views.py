from flask import Flask, Blueprint, render_template
from flask import url_for, request, redirect
from werkzeug.utils import secure_filename
import os
from os.path import join, dirname, abspath

from form_flask_select import SimpleForm
from variables import variables
from upload_file import UploadFileForm


views = Blueprint('views', __name__)

@views.route('/', methods=['GET', 'POST'])
def simple_form(): 
        form = SimpleForm()
        if form.is_submitted():
            result = request.form
            values = list(dict(result).values())
            variables.doc_type = values[0]
            return redirect('/documents')
        return render_template('simple_form_select.html', title="Выберите тип документов ",
                                header='Документы', form=form)



@views.route('/documents', methods=['GET', 'POST'])
def documents():
    form = UploadFileForm()
    if form.validate_on_submit():
        directory = "static/files"
        file = form.file.data  # grabbing the file
        for f in file:
            f.save(join(abspath(dirname(__file__)), directory, secure_filename(f.filename)))
        
        return redirect('/waiting')

    return render_template('documents.html', title='Загрузите документы', header='Документы', form=form)