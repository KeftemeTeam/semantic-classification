from flask import Flask, Blueprint, render_template
from flask import url_for, request, redirect
import os
import sys
from engine.loader.data_filter import DataFilter
from engine.loader.impl.rtf_loader import RTFLoader
from engine.loader.impl.docx_loader import DOCXLoader
from engine.language_model import LanguageModel
from engine.prompt_builder import PromptBuilder
from pathlib import Path

from variables import variables


waiting = Blueprint('waiting', __name__)

path=Path(r"D:\\hackathon\\semantic-classification\\website\\static\\files") #по другому ебучий патч не хочет работать

rtf = RTFLoader()
fl = DataFilter()
dx = DOCXLoader()
lm = LanguageModel("PetarDj/Mistal7B_0.2_ggml-model-Q6_K.gguf", "ggml-model-Q6_K.gguf", gpu_cores=36, context_size=32768)

def file2text():
    files = os.listdir(path)
    texts=[]
    for i in files:
        if i.split(".")[-1].lower() == "rtf":
            text = rtf.load_dataset(path+i)["text"]
            text = fl.filter(text)
            texts.append(text)
        elif i.split(".")[-1].lower() == "docx":
            text = dx.load_dataset(path+i)["text"]
            text = fl.filter(text)
            texts.append(text)
    return texts

def some_function():
    d_type = ["справка", "заявление", "заявление"] #это просто список какие документы и в каком количестве нужны(просто для теста)
    lst = []
    missed = []
    texts = file2text()
    promt = '' #здесь надо вызвать Promt Builder
    for i in texts:
        n_type = lm.generate()
        if n_type in d_type:
            d_type.remove(n_type) #удаляем из списка которых еще не нашли
            lst.append(n_type) #список найденных
    missed = d_type #все типы которые не нашли
    # работа модели
    # в lst закидываете, какие типы документов нашли
    # в missed закидываете, что не хватает, основываясь на целях пользователя (школьник, студент, рабочий, тд)
    doc_type = variables.doc_type  # школьные документы, документы в ВУЗ, документы на работу

    return result(lst, missed)

@waiting.route('/waiting')
def sleeping():
    return some_function()


@waiting.route('/result')
def result(lst, missed):
    #lst = ["справка", "заявление"]
    #missed = []
    s = ', '.join(lst)
    if len(missed) != 0:
        res = "Вам не хватает:" + ', '.join(missed)
    else:
        res = f"Ваши {variables.doc_type} будут рассмотрены"
    return render_template('result.html', docs=s, res=res)